import bpy
from bpy.props import (FloatProperty,
                      EnumProperty,
                      BoolProperty,
                      IntProperty,
                      PointerProperty, 
                      FloatVectorProperty,
                      StringProperty)
from bpy.types import PropertyGroup

class BloomItSettings(PropertyGroup):
    glare_type: EnumProperty(
        name="Bloom Type",
        description="Type of bloom effect",
        items=[
            ('FOG_GLOW', "Fog Glow", "Foggy bloom effect"),
            ('GHOSTS', "Ghosts", "Ghosting bloom effect"),
            ('STREAKS', "Streaks", "Streaky bloom effect"),
            ('SIMPLE_STAR', "Simple Star", "Star-shaped bloom")
        ],
        default='FOG_GLOW'
    )
    
    use_gamma_correction: BoolProperty(
        name="Use Gamma Correction",
        description="Apply gamma correction to the bloom effect",
        default=False
    )
    
    streaks: IntProperty(
        name="Streaks",
        description="Number of streaks (Only for Streaks type)",
        default=4,
        min=2,
        max=16
    )
    
    angle_offset: FloatProperty(
        name="Angle Offset",
        description="Rotation offset for the streaks",
        default=0.0,
        min=0.0,
        max=360.0,
        subtype='ANGLE'
    )
    
    fade: FloatProperty(
        name="Fade",
        description="Fade out factor for the streaks",
        default=0.9,
        min=0.0,
        max=1.0
    )
    
    # New properties
    color_tint: FloatVectorProperty(
        name="Color Tint",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        description="Color tint for the bloom effect"
    )

    use_color_tint: BoolProperty(
        name="Use Color Tint",
        default=False,
        description="Apply color tinting to the bloom effect"
    )

    use_mask: BoolProperty(
        name="Use Mask",
        default=False,
        description="Use a mask to control bloom areas"
    )

    mask_threshold: FloatProperty(
        name="Mask Threshold",
        default=0.5,
        min=0.0,
        max=1.0,
        description="Threshold for mask detection"
    )

    blur_quality: EnumProperty(
        name="Blur Quality",
        items=[
            ('FAST', "Fast", "Quick gaussian blur"),
            ('MEDIUM', "Medium", "Balanced blur quality"),
            ('HIGH', "High", "High quality blur")
        ],
        default='MEDIUM',
        description="Quality of blur preprocessing"
    )

    effect_layer: EnumProperty(
        name="Effect Layer",
        items=[
            ('ALL', "All Layers", "Apply bloom to all render layers"),
            ('SELECTED', "Selected Layer", "Apply bloom to selected render layer only"),
            ('CUSTOM', "Custom Mask", "Use custom mask for bloom")
        ],
        default='ALL',
        description="Choose which layers to apply bloom to"
    )

    preset_name: StringProperty(
        name="Preset Name",
        default="New Preset",
        description="Name for saving/loading presets"
    )

def register_properties():
    bpy.utils.register_class(BloomItSettings)
    bpy.types.Scene.bloomit_settings = PointerProperty(type=BloomItSettings)
    
    bpy.types.Scene.bloomit_size = IntProperty(
        name="Size",
        description="Size of the bloom effect",
        default=3,
        min=1,
        max=100,
        subtype='PIXEL'
    )
    
    bpy.types.Scene.bloomit_intensity = FloatProperty(
        name="Intensity",
        description="Intensity of the bloom effect",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    bpy.types.Scene.bloomit_threshold = FloatProperty(
        name="Threshold",
        description="Threshold for the bloom effect",
        default=1.0,
        min=0.0,
        max=10.0
    )
    
    bpy.types.Scene.bloomit_quality = EnumProperty(
        name="Quality",
        description="Quality of the bloom effect",
        items=[
            ('HIGH', "High", "High quality bloom"),
            ('MEDIUM', "Medium", "Medium quality bloom"),
            ('LOW', "Low", "Low quality bloom")
        ],
        default='MEDIUM'
    )
    
    bpy.types.Scene.bloomit_mix_factor = FloatProperty(
        name="Blend Factor",
        description="Blend factor between original and bloomed image",
        default=1.0,
        min=0.0,
        max=1.0
    )
    
    bpy.types.Scene.bloomit_gamma = FloatProperty(
        name="Gamma",
        description="Gamma correction value",
        default=1.0,
        min=0.0,
        max=5.0
    )
    
    bpy.types.Scene.bloomit_clear_nodes = BoolProperty(
        name="Clear Existing Nodes",
        description="Clear all existing nodes when creating bloom setup",
        default=True
    )

def unregister_properties():
    del bpy.types.Scene.bloomit_settings
    del bpy.types.Scene.bloomit_size
    del bpy.types.Scene.bloomit_intensity
    del bpy.types.Scene.bloomit_threshold
    del bpy.types.Scene.bloomit_quality
    del bpy.types.Scene.bloomit_mix_factor
    del bpy.types.Scene.bloomit_gamma
    del bpy.types.Scene.bloomit_clear_nodes
    bpy.utils.unregister_class(BloomItSettings)

def register():
    register_properties()

def unregister():
    unregister_properties()
