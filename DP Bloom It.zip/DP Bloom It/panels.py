import bpy
from bpy.types import Panel

class BLOOMIT_PT_main_panel(Panel):
    """Bloom It Panel"""
    bl_label = "Bloom It"
    bl_idname = "BLOOMIT_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Bloom It'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.bloomit_settings
        
        # Presets
        box = layout.box()
        box.label(text="Presets:")
        row = box.row(align=True)
        row.prop(settings, "preset_name", text="")
        row.operator("bloomit.save_preset", text="", icon='FILE_TICK')
        row.operator("bloomit.load_preset", text="", icon='FILE_FOLDER')
        
        # Basic Settings
        box = layout.box()
        box.label(text="Basic Settings:")
        box.prop(settings, "glare_type")
        box.prop(scene, "bloomit_size", text="Size")
        box.prop(scene, "bloomit_intensity", text="Intensity")
        box.prop(scene, "bloomit_threshold", text="Threshold")
        box.prop(scene, "bloomit_quality", text="Quality")
        
        # Color Settings
        box = layout.box()
        box.label(text="Color Settings:")
        box.prop(settings, "use_color_tint")
        if settings.use_color_tint:
            box.prop(settings, "color_tint")
        
        # Mask Settings
        box = layout.box()
        box.label(text="Mask Settings:")
        box.prop(settings, "effect_layer")
        if settings.effect_layer == 'CUSTOM':
            box.prop(settings, "use_mask")
            if settings.use_mask:
                box.prop(settings, "mask_threshold")
                box.operator("bloomit.add_mask")
        
        # Advanced Settings
        box = layout.box()
        box.label(text="Advanced Settings:")
        box.prop(scene, "bloomit_mix_factor", text="Blend Amount")
        box.prop(settings, "use_gamma_correction")
        if settings.use_gamma_correction:
            box.prop(scene, "bloomit_gamma", text="Gamma")
        box.prop(settings, "blur_quality")
        
        # Streak Settings
        if settings.glare_type == 'STREAKS':
            box = layout.box()
            box.label(text="Streak Settings:")
            box.prop(settings, "streaks")
            box.prop(settings, "angle_offset")
            box.prop(settings, "fade")
        
        # Options
        box = layout.box()
        box.label(text="Options:")
        box.prop(scene, "bloomit_clear_nodes")
        
        # Operators
        layout.separator()
        layout.operator("bloomit.create_bloom", text="Create Bloom")
        layout.operator("bloomit.update_bloom", text="Update Bloom")

def register():
    bpy.utils.register_class(BLOOMIT_PT_main_panel)

def unregister():
    bpy.utils.unregister_class(BLOOMIT_PT_main_panel)
