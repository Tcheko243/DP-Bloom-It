# utils.py
import bpy
import gpu
import bgl
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
import os
import json
from typing import List, Dict, Tuple, Optional, Any

class NodeUtils:
    @staticmethod
    def get_node_by_type(tree: bpy.types.NodeTree, node_type: str) -> Optional[bpy.types.Node]:
        """Find first node of specified type in the node tree."""
        return next((node for node in tree.nodes if node.type == node_type), None)

    @staticmethod
    def get_all_nodes_by_type(tree: bpy.types.NodeTree, node_type: str) -> List[bpy.types.Node]:
        """Find all nodes of specified type in the node tree."""
        return [node for node in tree.nodes if node.type == node_type]

    @staticmethod
    def clean_node_tree(tree: bpy.types.NodeTree) -> None:
        """Clean up disconnected nodes in the tree."""
        for node in tree.nodes:
            if not any(link.from_node == node for link in tree.links) and \
               not any(link.to_node == node for link in tree.links):
                tree.nodes.remove(node)

    @staticmethod
    def arrange_nodes(tree: bpy.types.NodeTree) -> None:
        """Automatically arrange nodes in the tree."""
        # Simple grid arrangement
        margin_x = 300
        margin_y = 200
        current_x = 0
        current_y = 0
        max_height = 0

        for node in tree.nodes:
            node.location = (current_x, current_y)
            max_height = max(max_height, node.dimensions.y)
            current_x += margin_x
            
            if current_x > 1920:  # Max width
                current_x = 0
                current_y -= max_height + margin_y
                max_height = 0

class PresetManager:
    PRESET_DIR = os.path.join(bpy.utils.user_resource('SCRIPTS'), "presets", "bloomit")

    @classmethod
    def ensure_preset_dir(cls) -> None:
        """Ensure preset directory exists."""
        os.makedirs(cls.PRESET_DIR, exist_ok=True)

    @classmethod
    def save_preset(cls, name: str, settings: Dict[str, Any]) -> bool:
        """Save settings as a preset."""
        cls.ensure_preset_dir()
        try:
            filepath = os.path.join(cls.PRESET_DIR, f"{name}.json")
            with open(filepath, 'w') as f:
                json.dump(settings, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving preset: {e}")
            return False

    @classmethod
    def load_preset(cls, name: str) -> Optional[Dict[str, Any]]:
        """Load settings from a preset."""
        try:
            filepath = os.path.join(cls.PRESET_DIR, f"{name}.json")
            with open(filepath, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading preset: {e}")
            return None

    @classmethod
    def get_all_presets(cls) -> List[str]:
        """Get list of all available presets."""
        cls.ensure_preset_dir()
        return [f[:-5] for f in os.listdir(cls.PRESET_DIR) if f.endswith('.json')]

    @classmethod
    def delete_preset(cls, name: str) -> bool:
        """Delete a preset."""
        try:
            filepath = os.path.join(cls.PRESET_DIR, f"{name}.json")
            os.remove(filepath)
            return True
        except Exception as e:
            print(f"Error deleting preset: {e}")
            return False

class ViewportDrawing:
    """Utility class for drawing in the viewport."""
    
    @staticmethod
    def draw_callback_px(self, context):
        """Draw callback for viewport overlay."""
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        
        # Draw bloom preview overlay
        if context.scene.bloomit_settings.show_overlay:
            width = context.region.width
            height = context.region.height
            
            vertices = ((0, 0), (width, 0), (width, height), (0, height))
            indices = ((0, 1, 2), (0, 2, 3))
            
            shader.bind()
            shader.uniform_float("color", (1, 1, 1, 0.1))
            
            batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
            batch.draw(shader)

class BloomCalculator:
    """Utility class for bloom calculations."""
    
    @staticmethod
    def calculate_optimal_blur(float_size: float) -> int:
        """Calculate optimal blur size based on image size and intensity."""
        return max(1, min(100, round(float_size)))

    @staticmethod
    def calculate_threshold(scene_exposure: float) -> float:
        """Calculate optimal threshold based on scene exposure."""
        return max(0.1, min(scene_exposure * 0.5, 5.0))

class PerformanceOptimizer:
    """Utility class for optimizing addon performance."""
    
    @staticmethod
    def get_optimal_quality(scene_resolution: Tuple[int, int]) -> str:
        """Determine optimal quality settings based on resolution."""
        pixel_count = scene_resolution[0] * scene_resolution[1]
        if pixel_count > 4096 * 4096:
            return 'LOW'
        elif pixel_count > 2048 * 2048:
            return 'MEDIUM'
        return 'HIGH'

    @staticmethod
    def optimize_node_tree(tree: bpy.types.NodeTree) -> None:
        """Optimize node tree for better performance."""
        # Remove duplicate nodes
        node_types = {}
        for node in tree.nodes:
            if node.type not in node_types:
                node_types[node.type] = []
            node_types[node.type].append(node)
            
        # Remove unnecessary duplicates
        for nodes in node_types.values():
            if len(nodes) > 1:
                for node in nodes[1:]:
                    if not node.outputs[0].links:
                        tree.nodes.remove(node)

class ErrorHandler:
    """Utility class for error handling."""
    
    @staticmethod
    def validate_settings(settings: Dict[str, Any]) -> Tuple[bool, str]:
        """Validate bloom settings."""
        try:
            required_fields = ['size', 'intensity', 'threshold']
            for field in required_fields:
                if field not in settings:
                    return False, f"Missing required field: {field}"
                
            if not 0 <= settings['intensity'] <= 1:
                return False, "Intensity must be between 0 and 1"
                
            return True, "Settings valid"
        except Exception as e:
            return False, str(e)

    @staticmethod
    def log_error(error: str, context: Optional[str] = None) -> None:
        """Log error message."""
        print(f"Bloom It Error {'(' + context + ')' if context else ''}: {error}")

def register():
    # Register any properties or handlers needed for utils
    bpy.types.Scene.bloomit_show_overlay = bpy.props.BoolProperty(
        name="Show Overlay",
        default=False,
        description="Show bloom effect overlay in viewport"
    )

def unregister():
    # Unregister properties and handlers
    del bpy.types.Scene.bloomit_show_overlay

# Example usage:
def example_usage():
    # Node utilities
    tree = bpy.context.scene.node_tree
    glare_node = NodeUtils.get_node_by_type(tree, 'GLARE')
    NodeUtils.arrange_nodes(tree)
    
    # Preset management
    preset_data = {
        "size": 3.0,
        "intensity": 0.5,
        "threshold": 1.0
    }
    PresetManager.save_preset("my_preset", preset_data)
    loaded_preset = PresetManager.load_preset("my_preset")
    
    # Performance optimization
    resolution = (1920, 1080)
    optimal_quality = PerformanceOptimizer.get_optimal_quality(resolution)
    
    # Error handling
    valid, message = ErrorHandler.validate_settings(preset_data)
    if not valid:
        ErrorHandler.log_error(message, "Preset Validation")
