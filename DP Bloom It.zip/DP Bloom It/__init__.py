bl_info = {
    "name": "Bloom It",
    "author": "Dimona Patrick",
    "version": (1, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Bloom It",
    "description": "Advanced bloom effect setup using Glare node",
    "category": "Render",
}

import bpy
from . import operators
from . import panels
from . import properties

modules = (
    properties,
    operators,
    panels
)

def register():
    for module in modules:
        module.register()

def unregister():
    for module in reversed(modules):
        module.unregister()

if __name__ == "__main__":
    register()
