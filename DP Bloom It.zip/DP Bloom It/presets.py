# presets.py
default_presets = {
    "Subtle Glow": {
        "glare_type": "FOG_GLOW",
        "size": 3.0,
        "intensity": 0.3,
        "threshold": 1.0,
        "quality": "MEDIUM",
        "mix_factor": 0.7
    },
    "Strong Bloom": {
        "glare_type": "FOG_GLOW",
        "size": 7.0,
        "intensity": 0.8,
        "threshold": 0.8,
        "quality": "HIGH",
        "mix_factor": 1.0
    },
    "Anamorphic Flare": {
        "glare_type": "STREAKS",
        "size": 15.0,
        "intensity": 0.6,
        "threshold": 1.2,
        "streaks": 2,
        "angle_offset": 1.5708, # 90 degrees
        "fade": 0.9
    }
}
