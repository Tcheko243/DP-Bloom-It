import bpy
import json
import os
from bpy.types import Operator
from bpy.props import StringProperty

class BLOOMIT_OT_create_bloom(Operator):
    """Create bloom effect setup"""
    bl_idname = "bloomit.create_bloom"
    bl_label = "Create Bloom"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Enable compositing nodes and use_nodes
        context.scene.use_nodes = True
        context.scene.render.use_compositing = True
        context.scene.render.use_sequencer = True
        
        tree = context.scene.node_tree
        settings = context.scene.bloomit_settings
        
        # Store existing nodes
        existing_nodes = []
        if not context.scene.bloomit_clear_nodes:
            existing_nodes = [(n.name, n.location.copy()) for n in tree.nodes]
            
        # Clear nodes if option is enabled
        if context.scene.bloomit_clear_nodes:
            tree.nodes.clear()
        
        # Restore existing nodes if needed
        for name, location in existing_nodes:
            if name in tree.nodes:
                tree.nodes[name].location = location
        
        # Create nodes
        render_layers = tree.nodes.new('CompositorNodeRLayers')
        render_layers.location = (-300, 0)
        
        # Create color correction nodes
        gamma = None
        if settings.use_gamma_correction:
            gamma = tree.nodes.new('CompositorNodeGamma')
            gamma.location = (-100, 0)
            gamma.inputs[1].default_value = context.scene.bloomit_gamma
        
        # Create glare node
        glare = tree.nodes.new('CompositorNodeGlare')
        glare.location = (0, 0)
        glare.glare_type = settings.glare_type
        glare.quality = context.scene.bloomit_quality
        glare.size = int(context.scene.bloomit_size)
        glare.mix = context.scene.bloomit_intensity
        glare.threshold = context.scene.bloomit_threshold
        
        if settings.glare_type == 'STREAKS':
            glare.streaks = settings.streaks
            glare.angle_offset = settings.angle_offset
            glare.fade = settings.fade
        
        # Create mix node for blend control
        mix = tree.nodes.new('CompositorNodeMixRGB')
        mix.location = (300, 0)
        mix.blend_type = 'ADD'
        mix.inputs[0].default_value = context.scene.bloomit_mix_factor
        
        # Create composite node
        composite = tree.nodes.new('CompositorNodeComposite')
        composite.location = (500, 0)
        
        # Link nodes
        if settings.use_gamma_correction:
            tree.links.new(render_layers.outputs['Image'], gamma.inputs[0])
            tree.links.new(gamma.outputs[0], glare.inputs[0])
        else:
            tree.links.new(render_layers.outputs['Image'], glare.inputs[0])
        
        tree.links.new(render_layers.outputs['Image'], mix.inputs[1])
        tree.links.new(glare.outputs[0], mix.inputs[2])
        tree.links.new(mix.outputs[0], composite.inputs[0])
        
        return {'FINISHED'}

class BLOOMIT_OT_update_bloom(Operator):
    """Update bloom effect parameters"""
    bl_idname = "bloomit.update_bloom"
    bl_label = "Update Bloom"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tree = context.scene.node_tree
        settings = context.scene.bloomit_settings
        
        if not tree:
            return {'CANCELLED'}
            
        for node in tree.nodes:
            if node.type == 'GLARE':
                node.glare_type = settings.glare_type
                node.quality = context.scene.bloomit_quality
                # Ensure size is an integer
                node.size = int(context.scene.bloomit_size)
                node.mix = context.scene.bloomit_intensity
                node.threshold = context.scene.bloomit_threshold
                
                if settings.glare_type == 'STREAKS':
                    node.streaks = settings.streaks
                    node.angle_offset = settings.angle_offset
                    node.fade = settings.fade
            
            elif node.type == 'MIX_RGB':
                node.inputs[0].default_value = context.scene.bloomit_mix_factor
                
            elif node.type == 'GAMMA':
                node.inputs[1].default_value = context.scene.bloomit_gamma
                
        return {'FINISHED'}
        


class BLOOMIT_OT_save_preset(Operator):
    """Save current bloom settings as preset"""
    bl_idname = "bloomit.save_preset"
    bl_label = "Save Preset"
    
    def execute(self, context):
        settings = context.scene.bloomit_settings
        preset_name = settings.preset_name
        
        preset_data = {
            "glare_type": settings.glare_type,
            "size": context.scene.bloomit_size,
            "intensity": context.scene.bloomit_intensity,
            "threshold": context.scene.bloomit_threshold,
            "quality": context.scene.bloomit_quality,
            "color_tint": list(settings.color_tint),
            "use_color_tint": settings.use_color_tint,
            # Add other settings...
        }
        
        preset_path = os.path.join(bpy.utils.user_resource('SCRIPTS'), 
                                 "presets", "bloomit")
        os.makedirs(preset_path, exist_ok=True)
        
        filepath = os.path.join(preset_path, f"{preset_name}.json")
        with open(filepath, 'w') as f:
            json.dump(preset_data, f)
        
        return {'FINISHED'}

class BLOOMIT_OT_load_preset(Operator):
    """Load saved bloom preset"""
    bl_idname = "bloomit.load_preset"
    bl_label = "Load Preset"
    
    filepath: StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        with open(self.filepath, 'r') as f:
            preset_data = json.load(f)
        
        settings = context.scene.bloomit_settings
        for key, value in preset_data.items():
            if hasattr(settings, key):
                setattr(settings, key, value)
            elif hasattr(context.scene, f"bloomit_{key}"):
                setattr(context.scene, f"bloomit_{key}", value)
        
        return {'FINISHED'}

    def invoke(self, context, event):
        preset_path = os.path.join(bpy.utils.user_resource('SCRIPTS'), 
                                 "presets", "bloomit")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class BLOOMIT_OT_add_mask(Operator):
    """Add mask node for bloom control"""
    bl_idname = "bloomit.add_mask"
    bl_label = "Add Mask"
    
    def execute(self, context):
        tree = context.scene.node_tree
        settings = context.scene.bloomit_settings
        
        # Create mask input node
        mask_input = tree.nodes.new('CompositorNodeMask')
        mask_input.location = (-500, -200)
        
        # Create threshold node
        threshold = tree.nodes.new('CompositorNodeMath')
        threshold.operation = 'GREATER_THAN'
        threshold.inputs[1].default_value = settings.mask_threshold
        threshold.location = (-300, -200)
        
        # Link mask to existing setup
        tree.links.new(mask_input.outputs[0], threshold.inputs[0])
        
        # Find glare node and add mask
        for node in tree.nodes:
            if node.type == 'GLARE':
                mix = tree.nodes.new('CompositorNodeMixRGB')
                mix.location = (node.location.x - 200, node.location.y)
                mix.blend_type = 'MULTIPLY'
                
                # Reroute existing connections
                input_links = [l for l in node.inputs[0].links]
                for link in input_links:
                    tree.links.new(link.from_socket, mix.inputs[1])
                    tree.links.remove(link)
                
                tree.links.new(threshold.outputs[0], mix.inputs[0])
                tree.links.new(mix.outputs[0], node.inputs[0])
        
        return {'FINISHED'}

def register():
    bpy.utils.register_class(BLOOMIT_OT_create_bloom)
    bpy.utils.register_class(BLOOMIT_OT_update_bloom)
    bpy.utils.register_class(BLOOMIT_OT_save_preset)
    bpy.utils.register_class(BLOOMIT_OT_load_preset)
    bpy.utils.register_class(BLOOMIT_OT_add_mask)

def unregister():
    bpy.utils.unregister_class(BLOOMIT_OT_update_bloom)
    bpy.utils.unregister_class(BLOOMIT_OT_create_bloom)
    bpy.utils.unregister_class(BLOOMIT_OT_add_mask)
    bpy.utils.unregister_class(BLOOMIT_OT_load_preset)
    bpy.utils.unregister_class(BLOOMIT_OT_save_preset)
