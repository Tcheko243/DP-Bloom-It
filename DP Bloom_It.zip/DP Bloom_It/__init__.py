bl_info = {
    "name": "Bloom It",
    "author": "Dimona Patrick",
    "version": (1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Bloom It",
    "description": "Quick bloom effect setup using Glare node",
    "category": "Compositing",
}

import bpy
from . import operators
from . import panels
from . import properties
from . import presets

modules = (
    properties,
    operators,
    panels,
    presets,
)

def register():
    for module in modules:
        module.register()

def unregister():
    for module in modules:
        module.unregister()

if __name__ == "__main__":
    register()
