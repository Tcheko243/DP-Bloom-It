import bpy
from bpy.types import Operator

class BLOOMIT_OT_setup_bloom(Operator):
    bl_idname = "bloomit.setup_bloom"
    bl_label = "Setup Bloom Effect"
    bl_description = "Setup bloom effect using Glare node"
    bl_options = {'REGISTER', 'UNDO'}

    def create_nodes(self, context):
        tree = context.scene.node_tree
        tree.nodes.clear()
        
        # Create basic nodes
        render_layers = tree.nodes.new('CompositorNodeRLayers')
        glare = tree.nodes.new('CompositorNodeGlare')
        mix_bloom = tree.nodes.new('CompositorNodeMixRGB')
        composite = tree.nodes.new('CompositorNodeComposite')
        
        nodes = {'render': render_layers, 'glare': glare, 
                'mix_bloom': mix_bloom, 'composite': composite}
        
        # Advanced nodes
        props = context.scene.bloom_it
        if props.use_gamma:
            gamma = tree.nodes.new('CompositorNodeGamma')
            gamma.inputs[1].default_value = props.gamma_value
            nodes['gamma'] = gamma
            
        if any(c != 1.0 for c in props.bloom_color):
            color = tree.nodes.new('CompositorNodeMixRGB')
            color.blend_type = 'MULTIPLY'
            color.inputs[1].default_value = (*props.bloom_color, 1)
            color.inputs[0].default_value = 1.0
            nodes['color'] = color
            
        if props.use_lens_dirt:
            dirt = tree.nodes.new('CompositorNodeImage')
            # You would need to load a lens dirt texture here
            mix_dirt = tree.nodes.new('CompositorNodeMixRGB')
            mix_dirt.blend_type = 'SCREEN'
            nodes['dirt'] = dirt
            nodes['mix_dirt'] = mix_dirt
            
        return nodes

    def setup_nodes(self, context, nodes):
        props = context.scene.bloom_it
        
        # Setup Glare node
        nodes['glare'].glare_type = props.glare_type
        nodes['glare'].quality = props.quality
        nodes['glare'].size = props.size
        nodes['glare'].threshold = props.threshold
        
        # Setup Mix node
        nodes['mix_bloom'].blend_type = 'SCREEN'
        nodes['mix_bloom'].inputs[0].default_value = props.mix

    def link_nodes(self, context, nodes):
        tree = context.scene.node_tree
        props = context.scene.bloom_it
        
        # Basic links
        input_node = nodes['render']
        bloom_node = nodes['glare']
        
        # Handle gamma
        if props.use_gamma:
            tree.links.new(input_node.outputs['Image'], nodes['gamma'].inputs[0])
            input_node = nodes['gamma']
            
        # Main bloom chain
        tree.links.new(input_node.outputs['Image'], bloom_node.inputs[0])
        
        # Handle color tint
        if 'color' in nodes:
            tree.links.new(bloom_node.outputs[0], nodes['color'].inputs[2])
            bloom_node = nodes['color']
            
        # Handle lens dirt
        if props.use_lens_dirt and 'dirt' in nodes:
            tree.links.new(bloom_node.outputs[0], nodes['mix_dirt'].inputs[1])
            tree.links.new(nodes['dirt'].outputs[0], nodes['mix_dirt'].inputs[2])
            bloom_node = nodes['mix_dirt']
            
        # Final mixing
        tree.links.new(bloom_node.outputs[0], nodes['mix_bloom'].inputs[1])
        tree.links.new(nodes['render'].outputs['Image'], nodes['mix_bloom'].inputs[2])
        tree.links.new(nodes['mix_bloom'].outputs[0], nodes['composite'].inputs[0])

    def execute(self, context):
        # Enable Use Nodes in Compositor
        context.scene.use_nodes = True
        
        # Create and setup node tree
        nodes = self.create_nodes(context)
        self.setup_nodes(context, nodes)
        self.link_nodes(context, nodes)
        
        # Set viewport settings
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'RENDERED'
                        space.shading.use_compositor = 'ALWAYS'
        
        # Enable compositor
        context.scene.render.use_compositing = True
        
        self.report({'INFO'}, "Bloom effect setup completed!")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(BLOOMIT_OT_setup_bloom)

def unregister():
    bpy.utils.unregister_class(BLOOMIT_OT_setup_bloom)
