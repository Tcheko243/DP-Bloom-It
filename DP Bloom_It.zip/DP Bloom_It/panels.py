import bpy
from bpy.types import Panel

class BLOOMIT_PT_main_panel(Panel):
    bl_label = "Bloom It"
    bl_idname = "BLOOMIT_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Bloom It"

    def draw(self, context):
        layout = self.layout
        props = context.scene.bloom_it
        
        # Setup button
        layout.operator("bloomit.setup_bloom", text="Bloom It!")
        
        # Basic Settings
        box = layout.box()
        box.label(text="Basic Settings:")
        box.prop(props, "glare_type")
        box.prop(props, "quality")
        box.prop(props, "size")
        box.prop(props, "threshold")
        box.prop(props, "mix")

        # Advanced Settings
        box = layout.box()
        box.label(text="Advanced Settings:")
        
        # Gamma correction
        row = box.row()
        row.prop(props, "use_gamma")
        if props.use_gamma:
            box.prop(props, "gamma_value")
        
        # Bloom color
        box.prop(props, "bloom_color")
        
        # Lens dirt
        box.prop(props, "use_lens_dirt")
        
        # Presets
        box = layout.box()
        box.label(text="Presets:")
        row = box.row()
        row.menu("BLOOMIT_MT_presets", text="Presets")
        row.operator("bloomit.preset_add", text="", icon='ADD')
        row.operator("bloomit.preset_remove", text="", icon='REMOVE')

def register():
    bpy.utils.register_class(BLOOMIT_PT_main_panel)

def unregister():
    bpy.utils.unregister_class(BLOOMIT_PT_main_panel)
