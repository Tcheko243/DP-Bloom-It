import bpy
from bpy.types import PropertyGroup
from bpy.props import FloatProperty, IntProperty, EnumProperty, BoolProperty, FloatVectorProperty
from .utils import update_bloom

class BloomItProperties(PropertyGroup):
    glare_type: EnumProperty(
        name="Bloom Type",
        description="Type of bloom effect",
        items=[
            ('BLOOM', "Bloom", "Regular bloom effect"),
            ('FOG_GLOW', "Fog Glow", "Fog glow effect"),
            ('SIMPLE_STAR', "Simple Star", "Simple star pattern"),
            ('STREAKS', "Streaks", "Streaks from bright areas"),
            ('GHOSTS', "Ghosts", "Lens ghosts")
        ],
        default='BLOOM',
        update=update_bloom
    )
    
    quality: EnumProperty(
        name="Quality",
        description="Quality of the bloom effect",
        items=[
            ('HIGH', "High", "High quality (slower)"),
            ('MEDIUM', "Medium", "Medium quality"),
            ('LOW', "Low", "Low quality (faster)")
        ],
        default='HIGH',
        update=update_bloom
    )
    
    size: IntProperty(
        name="Size",
        description="Size of the bloom effect",
        default=7,
        min=1,
        max=10,
        update=update_bloom
    )
    
    threshold: FloatProperty(
        name="Threshold",
        description="Brightness threshold for the bloom effect",
        default=0.8,
        min=0.0,
        max=1.0,
        update=update_bloom
    )
    
    mix: FloatProperty(
        name="Mix",
        description="Mix factor of the bloom effect",
        default=0.5,
        min=0.0,
        max=1.0,
        update=update_bloom
    )

    # Advanced settings
    use_gamma: BoolProperty(
        name="Use Gamma",
        description="Apply gamma correction before bloom",
        default=False,
        update=update_bloom
    )

    gamma_value: FloatProperty(
        name="Gamma",
        description="Gamma correction value",
        default=2.2,
        min=0.1,
        max=5.0,
        update=update_bloom
    )

    bloom_color: FloatVectorProperty(
        name="Bloom Color",
        description="Color tint for the bloom effect",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
        update=update_bloom
    )

    use_lens_dirt: BoolProperty(
        name="Use Lens Dirt",
        description="Add lens dirt effect to bloom",
        default=False,
        update=update_bloom
    )

def register():
    bpy.utils.register_class(BloomItProperties)
    bpy.types.Scene.bloom_it = bpy.props.PointerProperty(type=BloomItProperties)

def unregister():
    del bpy.types.Scene.bloom_it
    bpy.utils.unregister_class(BloomItProperties)
