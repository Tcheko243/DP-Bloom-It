import bpy
from bl_operators.presets import AddPresetBase
from bpy.types import Menu, Operator

class BLOOMIT_MT_presets(Menu):
    bl_label = "Bloom Presets"
    preset_subdir = "bloom_it"
    preset_operator = "script.execute_preset"
    draw = Menu.draw_preset

class BLOOMIT_OT_add_preset(AddPresetBase, Operator):
    bl_idname = "bloomit.preset_add"
    bl_label = "Add Bloom Preset"
    preset_menu = "BLOOMIT_MT_presets"
    preset_subdir = "bloom_it"

    preset_defines = [
        "scene = bpy.context.scene",
        "bloom_it = scene.bloom_it"
    ]

    preset_values = [
        "bloom_it.glare_type",
        "bloom_it.quality",
        "bloom_it.size",
        "bloom_it.threshold",
        "bloom_it.mix",
        "bloom_it.use_gamma",
        "bloom_it.gamma_value",
        "bloom_it.bloom_color",
        "bloom_it.use_lens_dirt"
    ]

class BLOOMIT_OT_remove_preset(Operator):
    bl_idname = "bloomit.preset_remove"
    bl_label = "Remove Bloom Preset"
    preset_menu = "BLOOMIT_MT_presets"
    preset_subdir = "bloom_it"

def register():
    bpy.utils.register_class(BLOOMIT_MT_presets)
    bpy.utils.register_class(BLOOMIT_OT_add_preset)
    bpy.utils.register_class(BLOOMIT_OT_remove_preset)

def unregister():
    bpy.utils.unregister_class(BLOOMIT_MT_presets)
    bpy.utils.unregister_class(BLOOMIT_OT_add_preset)
    bpy.utils.unregister_class(BLOOMIT_OT_remove_preset)
