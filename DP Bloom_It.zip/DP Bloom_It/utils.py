import bpy

def ensure_node_tree():
    """Ensure the compositor node tree is set up correctly"""
    scene = bpy.context.scene
    if not scene.use_nodes:
        scene.use_nodes = True
        
    tree = scene.node_tree
    if not tree.nodes:
        # Create basic node setup if none exists
        render_layers = tree.nodes.new('CompositorNodeRLayers')
        glare = tree.nodes.new('CompositorNodeGlare')
        mix_bloom = tree.nodes.new('CompositorNodeMixRGB')
        composite = tree.nodes.new('CompositorNodeComposite')
        
        # Position nodes
        render_layers.location = (-200, 0)
        glare.location = (0, 0)
        mix_bloom.location = (200, 0)
        composite.location = (400, 0)
        
        # Link nodes
        tree.links.new(render_layers.outputs['Image'], glare.inputs[0])
        tree.links.new(glare.outputs[0], mix_bloom.inputs[1])
        tree.links.new(render_layers.outputs['Image'], mix_bloom.inputs[2])
        tree.links.new(mix_bloom.outputs[0], composite.inputs[0])
    
    return tree

def get_bloom_nodes():
    """Get or create the necessary nodes for the bloom effect"""
    tree = ensure_node_tree()
    nodes = tree.nodes
    
    # Get or create required nodes
    glare = None
    mix_bloom = None
    gamma = None
    color = None
    mix_dirt = None
    
    for node in nodes:
        if node.type == 'GLARE':
            glare = node
        elif node.type == 'MIX_RGB':
            if not mix_bloom:
                mix_bloom = node
            elif node.blend_type == 'MULTIPLY':
                color = node
        elif node.type == 'GAMMA':
            gamma = node
            
    return {
        'tree': tree,
        'glare': glare,
        'mix_bloom': mix_bloom,
        'gamma': gamma,
        'color': color,
        'mix_dirt': mix_dirt
    }

def update_bloom(self, context):
    """Update the bloom effect when properties change"""
    nodes = get_bloom_nodes()
    if not nodes['glare']:
        return
    
    props = context.scene.bloom_it
    
    # Update Glare node
    glare = nodes['glare']
    glare.glare_type = props.glare_type
    glare.quality = props.quality
    glare.size = props.size
    glare.threshold = props.threshold
    
    # Update Mix node
    if nodes['mix_bloom']:
        nodes['mix_bloom'].inputs[0].default_value = props.mix
    
    # Handle gamma correction
    tree = nodes['tree']
    if props.use_gamma:
        if not nodes['gamma']:
            # Create and setup gamma node
            gamma = tree.nodes.new('CompositorNodeGamma')
            gamma.location = (-100, 100)
            gamma.inputs[1].default_value = props.gamma_value
            # Reconnect nodes
            input_node = None
            for node in tree.nodes:
                if node.type == 'R_LAYERS':
                    input_node = node
                    break
            if input_node:
                tree.links.new(input_node.outputs['Image'], gamma.inputs[0])
                tree.links.new(gamma.outputs[0], glare.inputs[0])
            nodes['gamma'] = gamma
        else:
            nodes['gamma'].inputs[1].default_value = props.gamma_value
    elif nodes['gamma']:
        # Remove gamma node and reconnect
        input_node = None
        for node in tree.nodes:
            if node.type == 'R_LAYERS':
                input_node = node
                break
        if input_node:
            tree.links.new(input_node.outputs['Image'], glare.inputs[0])
        tree.nodes.remove(nodes['gamma'])
    
    # Handle color tint
    if any(c != 1.0 for c in props.bloom_color):
        if not nodes['color']:
            # Create and setup color node
            color = tree.nodes.new('CompositorNodeMixRGB')
            color.location = (100, 100)
            color.blend_type = 'MULTIPLY'
            color.inputs[0].default_value = 1.0
            # Connect nodes
            tree.links.new(glare.outputs[0], color.inputs[1])
            tree.links.new(color.outputs[0], nodes['mix_bloom'].inputs[1])
            nodes['color'] = color
        nodes['color'].inputs[1].default_value = (*props.bloom_color, 1)
    elif nodes['color']:
        # Remove color node and reconnect
        tree.links.new(glare.outputs[0], nodes['mix_bloom'].inputs[1])
        tree.nodes.remove(nodes['color'])
    
    # Handle lens dirt
    if props.use_lens_dirt:
        if not nodes['mix_dirt']:
            # Setup lens dirt nodes (you would need to implement this based on your needs)
            pass
    elif nodes['mix_dirt']:
        # Remove lens dirt nodes
        tree.nodes.remove(nodes['mix_dirt'])
    
    # Ensure viewport settings
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.shading.type = 'RENDERED'
                    space.shading.use_compositor = 'ALWAYS'
    
    # Ensure compositor is enabled
    context.scene.render.use_compositing = True
